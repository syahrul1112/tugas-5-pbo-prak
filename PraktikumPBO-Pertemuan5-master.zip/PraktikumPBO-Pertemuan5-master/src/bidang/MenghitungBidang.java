
package bidang;

public interface MenghitungBidang {
    double luas();
    double keliling();
}
