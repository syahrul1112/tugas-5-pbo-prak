
package ruang;

public interface MenghitungRuang {
    double luas();
    double volume();
}
